package Controller;

import java.util.Scanner;

public class PlayerVsIAActions {
	
	private static Scanner scanner = new Scanner(System.in);
	//Tire une combinaison � deviner
	 
    void CombinaisonATrouver(int combinaison [], int n, int max) {
   for (int i = 0; i < n; i++) {
   combinaison [i] =(1 + (int) (Math.random() * max));
     }
 }

 /*Permet de lire la combinaison propos�e
  par le joueur*/  

  void CombinaisonJoueur(int combinaison [], int n){
   System.out.print("Entrez les " +n+ " chiffres de votre proposition");
   System.out.println("(Entrez votre chiffre et terminez par un retour chariot) :");
   for (int i = 0; i < n; i++) {
     combinaison[i] = scanner.nextInt();
   }
 }

 /*Permet de comparer la combinaison � deviner avec la
  combinaison propos�e par le joueur.
  Dans reponse[0] sera stock� le nombre d'�l�ments bien devin�s
  et correctement plac�s.
  Dans reponse[1] sera stock� le nombre d'�l�ments bien devin�s
  mais mal plac�s.
  return true si la bonne combinaison est trouv�e et sinon sa return false*/
   
   
   boolean compare(int n, int combinaison1 [], int combinaison2 [],int reponse []) {
   int nbMalPlace = 0;
   int nbBienPlace = 0;
   boolean [] marque = new boolean[n];
   boolean trouve = true;
   /*cette sert � trouver
   les �l�ments bien devin�s et correctement plac�s.
   Le tableau marque permet de marquer de tels
   �l�ments pour qu'ils ne soient pas compter
   plusieurs fois.*/
     for (int i = 0; i < n; i++) {
     if (combinaison1 [i] == combinaison2 [i]) {
   	  nbBienPlace++;
       marque[i] = true;
     } else {
       trouve = false;
       marque[i] = false;
     }
   }
     // la deuxi�me boucle suivante sert � identifier les
   // �l�ments bien devin�s mais mal plac�s.
   for (int i = 0; i < n; i++) {
     if (combinaison1[i] != combinaison2[i]) {
       int j = 0;
       boolean trouveMalPlace = false;
       while ((j < n) && !trouveMalPlace) {
         if (!marque[j] && (combinaison1[i] == combinaison2[j])) {
       	  nbMalPlace++;
           marque[j] = true;
           trouveMalPlace = true;
         }
         j++;
       }
     }
   }


   reponse[0] = nbBienPlace;
   reponse[1] = nbMalPlace;
   return trouve;
 }

   //Affichage d'une combinaison
    
 void afficheCombinaison(int combinaison [], int n) {
   for (int i = 0; i < n; i++)
     System.out.print(combinaison[i]);
   System.out.println(" ");
 };

   /*Affichage des indications destin�es au joueur*/
  
    
  void afficheReponse(int reponse []) {
   for (int i = 0; i < reponse[0]; i++)
   System.out.print('#');
   for (int i = 0; i < reponse[1]; i++)
     System.out.print('O');
   System.out.println();
 }

   //Affichage du texte d'acceuil
   
     
  void Informations(int n, int max, int maxCoups) {
    System.out.println(" **- MASTERMIND -**\n ");
    System.out.printf(" Les chiffres sont compris entre 1 et " +max+ " avec r�p�titions possibles\n");
    System.out.printf(" Vous avez " +maxCoups+ " chances pour trouver la solution !\n");
    System.out.println(" O indique un chiffre mal plac�e, # indique un chiffre bien plac� et un \" \" indique que le chiffre n\'est pas dans la solution.");
 }
  
   //Regle du MasterMind
public void mastermind(int size, int maxDigit, int maxCoups) {
   int solution [] = new int[size];
   int proposition [] = new int[size];
   int nbCoups = 0;
   boolean trouve = false;
   int reponse [] = new int[2];

   Informations(size, maxDigit, maxCoups);
   CombinaisonATrouver(solution, size, maxDigit);

   do {
     CombinaisonJoueur(proposition, size);
     nbCoups++;
     trouve = compare(size, solution, proposition, reponse);
     afficheReponse(reponse);
   }
   while (!trouve && (nbCoups < maxCoups));

   if (trouve) {
     System.out.print("Bravo ! Vous avez trouv� le code en ");
     System.out.print(nbCoups);
     System.out.println(" coups");
   }
   else {
     System.out.println("D�sol� ! Vous n'avez pas trouv� le bon code ...");
     System.out.println("Le bon code �tait : ");
     afficheCombinaison(solution, size);
     System.out.println("Au Revoir !!");
   }
 }
}
