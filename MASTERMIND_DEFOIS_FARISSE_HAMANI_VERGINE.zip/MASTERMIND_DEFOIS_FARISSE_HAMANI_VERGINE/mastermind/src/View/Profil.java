package View;

import Model.BddActions;
import java.util.Scanner;

public class Profil {
	
	private void afficheProfil() {
		BddActions pr = new BddActions();
		pr.lireEnBase();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Entrez le chiffre correspondant � la ligne choisie");
		System.out.println("1) Modifier Pseudo");
		System.out.println("2) Modifier mot de passe");
		System.out.println("3) Supprimer mon compte");
		int str = sc.nextInt();
				
		switch(str) {
		case 1 :
			String str1 = sc.next();
			System.out.println("Entrez votre nouveau pseudo");
			BddActions mp = new BddActions();
			mp.modifPseudoPlayerEnBase(str1);
			break;
		case 2 : String str2 = sc.next();
		System.out.println("Entrez votre nouveau pseudo");
		BddActions mmdp = new BddActions();
		mmdp.modifMdpPlayerEnBase(str2);
			break;
		case 3 : String strp = sc.next();
		BddActions de = new BddActions();
		de.SupprimePlayerEnBase(strp);
		default:
			}
	}
	
}
