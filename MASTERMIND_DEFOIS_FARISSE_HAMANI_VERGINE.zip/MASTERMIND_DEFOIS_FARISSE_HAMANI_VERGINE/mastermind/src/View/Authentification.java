package View;

import java.util.Scanner;
import Model.BddActions;

public class Authentification {
	private static Scanner sc;

	public static void selection() {
		sc = new Scanner(System.in);
		System.out.println("Entrez le chiffre correspondant � la ligne choisie");
		System.out.println("1) Connexion");
		System.out.println("2) Creer un compte");
		System.out.println("3) Quittez");
		int str = sc.nextInt();

		switch(str) {
		case 1 :
			System.out.println("Entrez votre pseudo");
		    String pseudo = sc.next();
		    System.out.println("Entrez votre mot de passe");
			String mdp = sc.next();
			BddActions co = new BddActions();
			co.ConnexionPlayer(pseudo, mdp);
			break;
		case 2 :
			System.out.println("Entrez votre pseudo");
			String strps = sc.next();
			System.out.println("Entrez votre mot de passe");
			String strmdp = sc.next();
			BddActions in = new BddActions();
			in.InscriptionPlayer(strps,strmdp );
			break;
                        
                case 3 :
                        int code = 0;
                        System.exit(code);
		default: System.out.println("Veuillez entrer un chiffre : 1 ou 2");
			}
	}
}
