package Model;

import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class BddActions {

	public static void InscriptionPlayer(int id, String pseudo, String mdp) {
		String url = "jdbc:derby://localhost:1527/mastermind";
		String login = "root";
		String passwd = "";
		Connection cn = null;
		Statement st = null;
		boolean exist = false;
		int numberRow = 0;

		try {
			((Statement) cn).getConnection();
			String query = "select count(*) from dataTable";
		    PreparedStatement st1 = cn.prepareStatement(query);
		    ResultSet rs = st1.executeQuery();
		    while(rs.next()){
		        numberRow = rs.getInt("count(*)");
		    }

		    if (numberRow > 0) {
	        	exist = true;
	        	System.out.println("Ce pseudo est d�j� pris");
	        } else {


			Class.forName("com.mysql.jdbc.Driver");

			cn = (Connection) DriverManager.getConnection(url, login, passwd);


			st = cn.createStatement();
			String sql = "INSERT INTO player (id,pseudo,mdp) VALUES ('"+ id + "','" + pseudo + "','" + mdp + "')";


			st.executeUpdate(sql);
	        }

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {

				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void lireEnBase() {

		String url = "jdbc:mysql://localhost/mastermind";
		String login = "root";
		String passwd = "";

		Connection cn = null;
		Statement st = null;
		ResultSet rs = null;
		try {

			Class.forName("com.mysql.jdbc.Driver");

			cn = (Connection) DriverManager.getConnection(url, login, passwd);

			st = cn.createStatement();
			String sql = "SELECT * FROM player";

			rs = st.executeQuery(sql);

			while (rs.next()) {
				System.out.print("Pseudo" + "\t" + "Mot de passe" + "\n");
				System.out.print(rs.getString("pseudo"));
				System.out.print("\t");
				System.out.print(rs.getString("mdp"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void modifMdpPlayerEnBase(String mdp) {

		String url = "jdbc:mysql://localhost/mastermind";
		String login = "root";
		String passwd = "";

		Connection cn = null;
		Statement st = null;
		int rs = 0;
		try {

			Class.forName("com.mysql.jdbc.Driver");

			cn = (Connection) DriverManager.getConnection(url, login, passwd);

			st = cn.createStatement();
			String sql = "UPDATE player SET mdp='" + mdp + "'";

			rs = st.executeUpdate(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void modifPseudoPlayerEnBase(String pseudo) {

		String url = "jdbc:mysql://localhost/mastermind";
		String login = "root";
		String passwd = "";

		Connection cn = null;
		Statement st = null;
		int rs = 0;
		try {

			Class.forName("com.mysql.jdbc.Driver");

			cn = (Connection) DriverManager.getConnection(url, login, passwd);

			st = cn.createStatement();
			String sql = "UPDATE player SET pseudo='" + pseudo + "'";

			rs = st.executeUpdate(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void SupprimePlayerEnBase(String pseudo) {

		String url = "jdbc:mysql://localhost/mastermind";
		String login = "root";
		String passwd = "";

		Connection cn = null;
		Statement st = null;
		int rs = 0;
		try {

			Class.forName("com.mysql.jdbc.Driver");

			cn = (Connection) DriverManager.getConnection(url, login, passwd);

			st = cn.createStatement();
			String sql = "DELETE FROM player WHERE id='" + pseudo + "'";

			rs = st.executeUpdate(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void ConnexionPlayer() {
		String url = "jdbc:mysql://localhost/mastermind";
		String login = "root";
		String passwd = "";
		Connection cn = null;
		Statement st = null;

		Scanner sc = new Scanner(System.in);

		boolean exist = false;
		int numberRow = 0;
		int rs = 0;

		try {

		    System.out.println("Entrez votre pseudo puis votre mot de passe");
		    String strpseudo = sc.next();
			String strmdp = sc.next();
			if (strpseudo == " ") {
				System.out.println("Veuillez entrer un pseudo");
			} else if (strmdp == " ") {
				System.out.println("Veuillez entrer un mot de passe");
			} else {
				((Statement) cn).getConnection();
				String query = "select count(*'" + strpseudo + "') from player";
			    PreparedStatement st1 = cn.prepareStatement(query);
			    ResultSet rs1 = st1.executeQuery();
			    while(rs1.next()){
			        numberRow = rs1.getInt("count(*)");
			    }
			    if (numberRow == 0) {
		        	exist = true;
		        	System.out.println("Ce pseudo n'existe pas, veuillez cr�er un compte");
		        }
				else {
					System.out.println("Bienvenue :)");
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

    public void InscriptionPlayer(String strps, String strmdp) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void ConnexionPlayer(String pseudo, String mdp) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
