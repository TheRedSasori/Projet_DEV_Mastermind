package View;
import java.util.Scanner;
import Controller.PlayerVsIAActions;

public class MenuPrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Authentification.selection();
		}

	private static void MenuPrincipal() {

	Scanner sc = new Scanner(System.in);
	System.out.println("Entrez le chiffre correspondant � la ligne choisie");
	System.out.println("1) Trouver la combinaison de l'ordinateur");
	System.out.println("2) Mettez l'ordinateur au d�fi");
	System.out.println("3) Afficher votre profil");
	System.out.println("4) Modifier vos informations");
	System.out.println("5) Afficher les statistiques");
	System.out.println("6) Quittez");
	int choix = sc.nextInt();

	switch(choix) {
	case 1 : PlayerVsIAActions m = new PlayerVsIAActions();
      m.mastermind(4, 9, 10);
	System.out.println("A vous de jouer !");
		break;
	case 2 : System.out.println("Mettez la machine � l\'�preuve !");
		break;
	case 3 :
		break;
	case 4 :
		break;
	case 5 :
		break;
	case 6 : sc.close();
		break;
	default:
		}
	}
}
